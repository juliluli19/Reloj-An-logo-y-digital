const deg = 6;

const horas = document.querySelector(".hora");
const minutos = document.querySelector(".minuto");
const segundos = document.querySelector(".segundo");
const relojDigital = document.getElementById("reloj-digital");

setInterval(() => {
    let tiempo = new Date();

    let hr = tiempo.getHours() * 30;
    let min = tiempo.getMinutes() * deg;
    let seg = tiempo.getSeconds() * deg;

    horas.style.transform = `rotate(${(hr) + (min/12)}deg)`;
    minutos.style.transform = `rotate(${min}deg)`;
    segundos.style.transform = `rotate(${seg}deg)`;

    // Actualizar el reloj digital
    let ampm = "AM";
    let horasDigitales = tiempo.getHours();
    if (horasDigitales > 12) {
        horasDigitales -= 12;
        ampm = "PM"; 
    }
    let minutosDigitales = tiempo.getMinutes();
    let segundosDigitales = tiempo.getSeconds();
    relojDigital.textContent = `${horasDigitales}:${minutosDigitales}:${segundosDigitales} ${ampm}`;
}, 1000);
